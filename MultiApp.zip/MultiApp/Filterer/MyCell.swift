//
//  MyCell.swift
//  Filterer
//
//  Created by Preet on 10.03.16.
//

import UIKit

class MyCell: UICollectionViewCell {

    @IBOutlet var imageView: UIImageView!
}
